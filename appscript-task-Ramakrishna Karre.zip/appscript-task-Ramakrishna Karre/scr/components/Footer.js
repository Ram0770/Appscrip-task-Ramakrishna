import React from 'react';

export default function Footer() {
  return (
    <footer className="plp-footer">
      <div className="container footer-inner">
        <div>© {new Date().getFullYear()} Appscrip Task — Demo</div>
        <div className="muted">Responsive • Semantic HTML • SEO</div>
      </div>
    </footer>
  );
}
