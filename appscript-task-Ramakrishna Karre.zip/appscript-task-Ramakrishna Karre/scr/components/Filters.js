import React from 'react';

export default function Filters({
  categories,
  selectedCategories,
  toggleCategory,
  priceRange,
  setPriceRange,
  minMax,
  reset,
}) {
  function handlePriceChange(e, which) {
    const val = Number(e.target.value);
    if (which === 'min') setPriceRange((p) => [Math.min(val, p[1]), p[1]]);
    else setPriceRange((p) => [p[0], Math.max(val, p[0])]);
  }

  return (
    <div>
      <h2 id="filters-heading">Filters</h2>

      <section className="filter-block">
        <h3>Categories</h3>
        {categories.length === 0 ? (
          <p className="muted">Loading categories...</p>
        ) : (
          <ul className="category-list">
            {categories.map((cat) => (
              <li key={cat}>
                <label>
                  <input
                    type="checkbox"
                    checked={selectedCategories.includes(cat)}
                    onChange={() => toggleCategory(cat)}
                  />
                  <span className="cat-label">{cat}</span>
                </label>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="filter-block">
        <h3>Price</h3>
        <div className="price-inputs">
          <div>
            <label>Min</label>
            <input type="number" min={minMax[0]} max={minMax[1]} value={priceRange[0]} onChange={(e) => handlePriceChange(e, 'min')} />
          </div>
          <div>
            <label>Max</label>
            <input type="number" min={minMax[0]} max={minMax[1]} value={priceRange[1]} onChange={(e) => handlePriceChange(e, 'max')} />
          </div>
        </div>
        <div className="slider-row">
          <input type="range" min={minMax[0]} max={minMax[1]} value={priceRange[0]} onChange={(e) => handlePriceChange(e, 'min')} />
          <input type="range" min={minMax[0]} max={minMax[1]} value={priceRange[1]} onChange={(e) => handlePriceChange(e, 'max')} />
        </div>
      </section>

      <section className="filter-block">
        <h3>Quick actions</h3>
        <button className="btn" onClick={reset}>
          Reset filters
        </button>
      </section>
    </div>
  );
}
