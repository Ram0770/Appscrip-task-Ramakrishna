import React from 'react';

export default function ProductCard({ product }) {
  return (
    <article className="product-card" id={`product-${product.id}`} itemScope itemType="http://schema.org/Product">
      <div className="img-wrap">
        <img src={product.image} alt={`Image of ${product.title}`} loading="lazy" />
      </div>
      <div className="card-body">
        <h2 className="product-title" itemProp="name">{product.title}</h2>
        <p className="product-category muted">{product.category}</p>
        <div className="price-row">
          <strong itemProp="offers" itemScope itemType="http://schema.org/Offer">
            <span itemProp="priceCurrency" content="USD">$</span>
            <span itemProp="price">{Number(product.price).toFixed(2)}</span>
          </strong>
          <button className="btn-outline">Add to Cart</button>
        </div>
      </div>
    </article>
  );
}
