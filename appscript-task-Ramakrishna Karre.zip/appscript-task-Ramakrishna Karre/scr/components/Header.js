import React from 'react';

export default function Header({ search, setSearch }) {
  return (
    <header className="plp-header">
      <div className="container header-inner">
        <div className="logo">appscrip-demo</div>
        <nav className="nav" aria-label="Main navigation">
          <a href="#">Home</a>
          <a href="#">Shop</a>
          <a href="#">Contact</a>
        </nav>
        <div className="search" role="search">
          <input
            aria-label="Search products"
            placeholder="Search products, e.g. 'shirt'"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>
    </header>
  );
}
