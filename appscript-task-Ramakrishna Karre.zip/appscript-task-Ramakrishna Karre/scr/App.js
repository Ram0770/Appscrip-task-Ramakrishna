import React, { useEffect, useState, useMemo } from 'react';
import Header from './components/Header';
import Filters from './components/Filters';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';

export default function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // UI state
  const [search, setSearch] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [minMax, setMinMax] = useState([0, 1000]);

  useEffect(() => {
    // Fetch from Fake Store API
    let mounted = true;
    fetch('https://fakestoreapi.com/products')
      .then((r) => {
        if (!r.ok) throw new Error('Network response not ok');
        return r.json();
      })
      .then((data) => {
        if (!mounted) return;
        setProducts(data);
        const prices = data.map((p) => Number(p.price));
        const min = Math.floor(Math.min(...prices));
        const max = Math.ceil(Math.max(...prices));
        setMinMax([min, max]);
        setPriceRange([min, max]);
        setLoading(false);
      })
      .catch((err) => {
        if (!mounted) return;
        setError(err.message);
        setLoading(false);
      });
    return () => (mounted = false);
  }, []);

  useEffect(() => {
    document.title = 'Product Listing Page — Appscrip Task';
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = 'Browse demo product listing page with filters and search.';
  }, []);

  const categories = useMemo(() => {
    const s = new Set(products.map((p) => p.category));
    return Array.from(s);
  }, [products]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = p.title.toLowerCase().includes(search.trim().toLowerCase());
      const matchesCategory = selectedCategories.length ? selectedCategories.includes(p.category) : true;
      const matchesPrice = p.price >= priceRange[0] && p.price <= priceRange[1];
      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [products, search, selectedCategories, priceRange]);

  // JSON-LD for SEO (ItemList)
  useEffect(() => {
    const items = filtered.slice(0, 10).map((p, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: window.location.href + '#product-' + p.id,
      name: p.title,
    }));
    const jsonld = { '@context': 'https://schema.org', '@type': 'ItemList', itemListElement: items };
    let script = document.getElementById('site-jsonld');
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = 'site-jsonld';
      document.head.appendChild(script);
    }
    script.text = JSON.stringify(jsonld);
  }, [filtered]);

  return (
    <div className="plp-root">
      <Header search={search} setSearch={setSearch} />
      <main className="container main">
        <aside className="filters" aria-labelledby="filters-heading">
          <Filters
            categories={categories}
            selectedCategories={selectedCategories}
            toggleCategory={(cat) =>
              setSelectedCategories((prev) => (prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]))
            }
            priceRange={priceRange}
            setPriceRange={setPriceRange}
            minMax={minMax}
            reset={() => {
              setSearch('');
              setSelectedCategories([]);
              setPriceRange(minMax);
            }}
          />
        </aside>

        <section className="content" aria-live="polite">
          <div className="toolbar">
            <h1>Products</h1>
            <div className="results-count">{loading ? '...' : `${filtered.length} results`}</div>
          </div>

          {error && <div className="error">API error: {error}</div>}
          {loading ? (
            <div className="loading">Loading products…</div>
          ) : (
            <ProductGrid products={filtered} />
          )}
        </section>
      </main>
      <Footer />
    </div>
  );
}
